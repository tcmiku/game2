#!/usr/bin/env python3
"""Read-only NIGHTFALL handoff inventory; requires only Python's standard library."""

import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import sys


CORE_FILES = (
    "app/page.tsx", "app/layout.tsx", "lib/game.mjs",
    "lib/equipment.mjs", "lib/camp-renderer.mjs",
)
ART_FILES = (
    "pixel-weapons.png", "pixel-weapon-vfx.png", "pixel-actors.png",
    "pixel-foes.png", "pixel-bestiary.png", "pixel-frontier.png",
    "pixel-sanctuary.png", "pixel-sanctuary-statues.png", "pixel-npc-glyphs.png",
    "pixel-shrine-stone.png",
)
GENERATORS = (
    "draw_pixel_art.py", "draw_frontier_art.py", "draw_actor_art.py",
    "draw_bestiary_art.py", "draw_camp_art.py", "draw_arsenal_expansion.py",
    "draw_ritual_art.py", "draw_pelican_art.py", "draw_zmd_art.py",
    "draw_sanctuary_art.py", "draw_weapon_vfx.py", "draw_npc_portraits.py",
)


def package_at(path):
    try:
        data = json.loads((path / "package.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) and data.get("name") == "nightfall-survivors" else None


def locate(path):
    if not path.is_dir():
        raise ValueError(f"目录不存在：{path}")
    if package_at(path):
        return path, [path]
    candidates = sorted(
        (child for child in path.iterdir()
         if not child.name.startswith(".") and child.is_dir() and package_at(child)),
        key=lambda child: child.name,
    )
    if not candidates:
        raise ValueError("当前目录及其直接子目录未找到 nightfall-survivors；请传入实际项目目录。")
    if len(candidates) == 1:
        return candidates[0], candidates
    main = next((child for child in candidates if child.name == "nightfall"), None)
    if main is None:
        names = "、".join(str(child) for child in candidates)
        raise ValueError(f"找到多份项目，请传入需要接手的具体目录：{names}")
    return main, candidates


def png_size(path):
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError("不是有效的 PNG 头")
    return struct.unpack(">II", header[16:24])


def integer_constant(source, name):
    match = re.search(r"\b" + re.escape(name) + r"\s*=\s*(\d+)\b", source)
    return int(match.group(1)) if match else None


def read_source(project, relative):
    try:
        return (project / relative).read_text(encoding="utf-8")
    except OSError:
        return ""


def inspect(project, candidates):
    issues = []
    package = package_at(project)
    print(f"项目：{project}")
    if len(candidates) > 1:
        print("同级项目：" + "、".join(child.name for child in candidates))
        print("按本项目约定选择 nightfall；需要另一份时传入其完整路径，不自动同步。")
    engines = package.get("engines", {})
    print(f"包名：{package['name']}；Node：{engines.get('node', '未声明')}")
    missing = [relative for relative in CORE_FILES if not (project / relative).is_file()]
    if missing:
        issues.append("核心文件缺失：" + "、".join(missing))
    else:
        print("页面、绘制与装备入口：齐全")

    layout = read_source(project, "app/layout.tsx")
    css = re.findall(r"import\s+['\"]([^'\"]+\.css)['\"]", layout)
    print("CSS 导入顺序：" + (" → ".join(css) or "未识别，请查看 app/layout.tsx"))

    sizes = {}
    print("关键 PNG（public/art）：")
    for name in ART_FILES:
        try:
            sizes[name] = png_size(project / "public/art" / name)
            print(f"  {name}: {sizes[name][0]}×{sizes[name][1]}")
        except (OSError, ValueError) as error:
            issues.append(f"{name} 无法读取尺寸：{error}")

    equipment = read_source(project, "lib/equipment.mjs")
    columns = integer_constant(equipment, "WEAPON_ATLAS_COLUMNS")
    rows = integer_constant(equipment, "WEAPON_ATLAS_ROWS")
    if columns and rows:
        expected = (columns * 64, rows * 64)
        print(f"武器常量：{columns} 列×{rows} 行；按现行 64px 单元应为 {expected[0]}×{expected[1]}")
        if "pixel-weapons.png" in sizes and sizes["pixel-weapons.png"] != expected:
            issues.append("武器 PNG 与行列常量不一致；检查是否被旧绘图脚本覆盖。")
    else:
        print("武器常量未识别；请人工检查现行取样接口。")

    vfx = read_source(project, "lib/weapon-vfx.mjs")
    cell = integer_constant(vfx, "VFX_CELL")
    frames = integer_constant(vfx, "VFX_FRAMES")
    row_match = re.search(r"\bVFX_ROWS\s*=\s*\{([^}]+)\}", vfx)
    indices = re.findall(r":\s*(\d+)\b", row_match.group(1)) if row_match else []
    if cell and frames and indices:
        expected = (frames * cell, (max(map(int, indices)) + 1) * cell)
        print(f"VFX 常量对应尺寸：{expected[0]}×{expected[1]}")
        if "pixel-weapon-vfx.png" in sizes and sizes["pixel-weapon-vfx.png"] != expected:
            issues.append("VFX PNG 与特效常量不一致。")

    absent = [name for name in GENERATORS if not (project / "tools" / name).is_file()]
    print(f"绘图脚本：{len(GENERATORS) - len(absent)}/{len(GENERATORS)} 存在")
    if absent:
        print("  未找到：" + "、".join(absent) + "；可能已经迁移，请查看现行源码。")
    print("立绘提示：" + ("存在" if (project / "art/npc-portrait-prompts.json").is_file() else "未找到"))

    try:
        result = subprocess.run(
            ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "status", "--porcelain=v1"],
            cwd=project, capture_output=True, text=True, timeout=15, check=False,
        )
        if result.returncode == 0:
            changed = result.stdout.splitlines()
            print(f"Git 工作区：{len(changed)} 条改动记录" if changed else "Git 工作区：干净")
            for line in changed[:12]:
                print("  " + line)
            if len(changed) > 12:
                print(f"  ……另有 {len(changed) - 12} 条；在项目内查看完整 git status。")
        else:
            print("Git 状态不可用；不推断为干净工作区。")
    except (OSError, subprocess.TimeoutExpired):
        print("Git 状态未能读取；不推断为干净工作区。")

    for issue in issues:
        print("需核对：" + issue)
    print("只读检查结束。未启动服务、重绘、同步或发布；画面仍需在本地浏览器验证。")
    return 1 if issues else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_dir", nargs="?", default=".", help="项目目录，或包含其直接子目录的工作区")
    args = parser.parse_args()
    try:
        project, candidates = locate(Path(args.project_dir).expanduser().resolve())
        return inspect(project, candidates)
    except (OSError, ValueError) as error:
        print(f"无法检查：{error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
