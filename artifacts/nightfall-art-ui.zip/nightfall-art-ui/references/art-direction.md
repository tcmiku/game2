# 美术方向与资源约定

## 视觉基准

| 需要看的内容 | 参考图 |
| --- | --- |
| 月夜樱庭、中央大像与两侧小像 | [祈愿庭院](images/sanctuary-sakura-court.jpg) |
| 鸟居与营地北侧石阶 | [鸟居入口](images/sanctuary-torii-entrance.jpg) |
| 像素图标、刀刃、机关与神器 | [武器图集预览](images/weapons-preview.png) |
| 怪物轮廓、骨骼、植物与装甲 | [怪物预览](images/bestiary-preview.png) |
| 电线塔、通电连线 | [zmd科技](images/zmd-grid.png) |
| 舰影、锁定圈、轨道贯击 | [帝江号轨道炮](images/dijiang-orbital.png) |
| NPC 对话立绘与场景融合 | [药师对话](images/npc-herbalist-mobile.jpg) |

使用图片工具实际查看相关参考图，不只依赖文件名。药师图侧重人物与窄屏场景关系；庭院 UI 的最新精简程度以 UI 参考中的新版图为准。

## 基础风格

- 俯视/四分之三视角，古旧石庭和森林遗迹；可活动区域平坦、安静，装饰集中在边缘与设施周围。
- 冷蓝黑轮廓、灰绿石板和苔藓，角色与武器用月白、骨白、少量古金提亮。祈愿庭院周围为灰粉樱花树、暗梅色树影，花瓣有离散像素的飘落动画；营地北侧入口为暗朱鸟居、旧金饰边和褪白垂纸。火焰为温琥珀；传送门偏蓝紫；灵体偏青绿。强调物保持克制。
- 轮廓、色块、短裂纹、布料和苔藓按离散像素簇绘制。不要用随机噪点、照片滤镜或柔焦代替纹理；不要让阴影与装饰挤满战斗中心。
- 角色、雕像、图标必须先有可读轮廓，再补细节。以实际 32–96px 显示尺寸判断识别度，而非只放大看纹理。
- 像素图片使用 nearest-neighbor；Canvas `imageSmoothingEnabled=false`，CSS `image-rendering:pixelated`。阴影、火光、面板照明可柔和渐变，实体边缘保持像素感。
- 动作应读得出准备、命中、收势；已有角色采用 2 帧待机、6 帧行走、4 帧攻击。冻结/死亡/减弱动态由现有 `actorPose` 控制。

## 当前图集接口

以下是 2026-10-16 本地快照。改动前读取现行常量及 PNG 尺寸，不把这张表当作永远不变的规格。

| 文件（public/art） | 当前尺寸 | 约定 |
| --- | --- | --- |
| pixel-weapons.png | 384×576 | 6 列×9 行，64px 单元；`sprite - 16` 转图集序号 |
| pixel-weapon-vfx.png | 768×1152 | 96px 单元，8 帧×12 类特效；`VFX_ROWS` 定义类别 |
| pixel-actors.png | 1152×576 | 12 帧×6 行，96px 单元 |
| pixel-foes.png | 1152×288 | 原有新增敌人两行，第三行含弹丸等；96px 单元 |
| pixel-bosses.png | 1120×448 | 五列首领×两行姿态，每格 224px；boss-presentation.mjs 负责缩放与镜头 |
| pixel-bestiary.png | 1152×480 | 12 帧×5 行，对应类型 8–12 |
| pixel-frontier.png | 1200×800 | 绘制到 3600×2400 战场 |
| pixel-sanctuary.png | 1280×840 | 庭院背景，放置于世界 y=-800 |
| pixel-sanctuary-statues.png | 640×192 | 5 列，128×192 单元；中央巨像、剑、叶、羽、星 |
| pixel-npc-glyphs.png | 384×32 | 12 个 32px 符印，UI 常按 48px 显示 |
| pixel-shrine-stone.png | 96×96 | 供奉 UI 的低对比石纹，CSS 背景，不在 renderer 图片清单中 |

`ACTOR_ROWS=16` 描述逻辑角色类型，不代表某一张 actor PNG 有 16 行。类型 13–15 由 expanded-foes.mjs 绘制，五种首领使用独立的 224px 图集（boss-presentation.mjs / tools/draw_boss_art.py）；不向旧 bestiary PNG 追加不存在的行。真实取样映射在 `Renderer.actor()`；先选 actors/foes/bestiary 再计算行。

## 代码绘制与素材来源

| 内容 | 优先定位 |
| --- | --- |
| 主战场与基础物件 | tools/draw_pixel_art.py、tools/draw_frontier_art.py |
| 营地石庭、火堆、传送门 | tools/draw_camp_art.py、lib/camp-renderer.mjs |
| 基础人物与动作 | tools/draw_actor_art.py、lib/animation.mjs |
| 新怪物 | tools/draw_bestiary_art.py、lib/bestiary.mjs |
| 武器和神器图标 | tools/draw_arsenal_expansion.py、draw_ritual_art.py、draw_pelican_art.py、draw_zmd_art.py、draw_meme_art.py |
| 动态攻击特效 | lib/weapon-vfx.mjs、lib/arsenal-ritual.mjs、lib/pelican.mjs、lib/zmd.mjs、lib/meme-arsenal.mjs |
| 庭院、樱花树、雕像与石纹 | tools/draw_sanctuary_art.py、lib/sanctuary.mjs |
| 鸟居、落樱、雕像光效与注火 | lib/camp-renderer.mjs 的 torii、petals、shrineAura、ritual |

不要为小幅 UI 调整重跑整套绘图。当前 `draw_pixel_art.py` 汇总流程结束于旧仪式图集，未串入后来加入的鹈鹕/科技图标；`draw_frontier_art.py` 和 `draw_ritual_art.py` 也会创建较短的 weapons 图集。直接重跑会覆盖后追加槽位。确需重绘时先查看输出文件、保留现有自定义内容，并按现有流程补回 pelican → zmd → meme；最后核对所有索引及图集尺寸。当前图集 sprite 60–63 已填满最后四格，33 件基础武器与 23 件神器当前共用 6×9 图集，第九行含后追加组合神器，未来以当前取样常量与索引为准。不要把固定重绘顺序推广到未来新增内容。

### NPC 对话立绘

现行四位立绘是已认可的生成素材，场景小人、地图和图标仍是代码绘制。`ART-PROMPTS.md` 的旧“手绘战场”提示是历史稿，不是当前像素资源的替换依据。`draw_npc_portraits.py` 中有旧 fallback 绘制函数；其现行 `generate()` 只生成符印，故意保留现有对话立绘。

新增同类 NPC 时读 [现行立绘提示](npc-portrait-prompts.json)。关键特征：单人半身、头手完整、偏向右侧、透明背景、蓝黑边缘、像素簇、旧金与象牙白、火光边缘照明；不含场景、文字、框或 UI。保持人物身份、道具、尺度及色系。只在需要生成/编辑位图时调用可用的图像工具，不能以这条参考要求每次改 UI 都重新生图。

庭院光效只根据已保存的雕像等级显示；未唤醒小像保持沉静，已唤醒小像使用各自强调色的符环、薄光和光尘。供奉后有短促增强。鸟居按世界 y 排序遮挡人物，DOM 点击区使用返回的 gate 投影，点击后沿既有路线绕过营地传送门。花瓣与呼吸光效在减弱动态模式下静止。


## 大型首领像素精度

首领原生 224×224，五列依次为枯枝、棱镜、空环、断界、死神，两行为常态与施法。显示高度分别为 368 / 400 / 384 / 420 / 340；保持 nearest-neighbor，不把旧简陋几何形状再次放大代替细化。新绘图只运行 tools/draw_boss_art.py，不触碰旧武器/人物图集。参考 [原生首领图集](../assets/bosses-native.png)。bossCamera 预留上方血条与窄屏队友信息区，Renderer 平滑切换镜头；改大小时也核对接触半径和手机视野。
