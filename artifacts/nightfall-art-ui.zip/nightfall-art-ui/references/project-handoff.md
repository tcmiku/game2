# 项目接手说明

以下记录的是 2026-10-16 已完成的本地状态，后续以源码及用户最新要求为准。

## 定位与本地偏好

常用工作区：`/Users/mac/workspace/codex-working/game2`。

- `nightfall/`：当前主要开发与运行目录。
- `nightfall-bestiary-ui/`：另一个本地 checkout；近期扩展以 nightfall 为准，不假定两者相同或自动覆盖。
- 根目录自身也是 Git 仓库，包含子仓库和旧压缩包。仅在根执行 `git diff` 可能只看到子模块标记；到实际项目内检查状态。

用户明确要求后续不用发布、只保留本地。原在线游戏不能代表当前本地功能。不要为了“接手”而运行 source workflow、提交推送、注册新 Site、重新部署或用旧 tar.gz 覆盖目录。

先检查 `package.json`、`app/page.tsx`、`app/layout.tsx`、目标组件和目标 CSS，再核对已有修改。需要同步两个目录时只同步此次文件，先比较目标内容并保留独立修改；不要复制 `.git`、node_modules、.wrangler 或存档。

在别的机器上使用此 skill 时，不硬编码依赖这个绝对路径；从用户指定项目或当前目录定位同名源码结构。辅助脚本可接受显式路径。

## 模块地图

| 任务 | 源码 |
| --- | --- |
| 页面状态、暂停、出发/返回、营地命中区 | app/page.tsx |
| CSS 生效顺序 | app/layout.tsx |
| 通用与最终 UI 风格 | app/globals.css、nightfall-theme.css、npc-panels.css、interface.css、sanctuary.css |
| 庭院单座祈福页/输入 | components/game/sanctuary-panel.tsx |
| 连续注火、取消及单次提交 | lib/shrine-ritual.mjs |
| NPC 对话壳与焦点 | components/game/npc-encounter.tsx、use-panel-focus.ts |
| 营地存档/强化/出发属性 | lib/camp.mjs |
| 庭院雕像/费用/祝福/寻路 | lib/sanctuary.mjs |
| 营地与庭院镜头、世界投影 | lib/camp-renderer.mjs |
| 武器、神器、图标与配方定义 | lib/equipment.mjs |
| 房主模拟与战场 renderer | lib/game.mjs |
| 攻击表现 | lib/weapon-vfx.mjs、arsenal-extra.mjs、arsenal-ritual.mjs、pelican.mjs、zmd.mjs |
| 小怪弹幕抵消几何 | lib/counterfire.mjs |
| 资源加载/重试 | lib/assets.mjs |
| 联机校验与快照 | app/api/room/route.ts、lib/network.mjs、snapshot-delta.mjs |

## 需延续的现有内容

- **热梗兵装**：33 种基础武器。旋转猫咪可发射穿透、咕咕嘎嘎为企鹅连环声波、曼波小马蓄力冲锋、香蕉猫落地留下滑倒果皮；源码 lib/meme-arsenal.mjs，原创图标 tools/draw_meme_art.py，来源记录 art/meme-weapon-references.md。
- **随机物件**：每局由房主生成 70 个，避开四个出生点并保持间距。World.restore 直接沿用快照 props，不重新随机；破坏及掉落仍只结算一次。
- **共享经验**：lib/team-experience.mjs 是联机经验、等级、人数缩放、幽灵补领奖励的唯一来源，components/game/experience-hud.tsx 渲染队伍条。拾取只调用一次 World.xp，禁止重新循环给所有玩家加经验。快照保留 teamXp 与 player.upgradeCredits；旧个人进度接管时迁移。
- **人数与首领扩展**：lib/difficulty.mjs 按在线存活人数调节新敌人；lib/bosses.mjs 保留枯枝并加入棱镜、空环、断界三种技能和造型。components/game/boss-hud.tsx + app/boss-hud.css 提供五秒危险预警和分段血条。首领在场时减刷新并停精英批次。lib/expanded-foes.mjs 添加雾灯妖、蚀月蛛、空壳镜灵。
- **铁匠淬炼**：解锁后可在同一面板永久强化三级，每级增加该道具局内上限 1。profile.smithwork 经 expeditionBoons → 房间 input.boons → makePlayer 进入每个玩家，出发后固定；UI 用 upgradeMax，不能继续写死 def.max。


- **佩丽卡电锯**：持锯鹈鹕追敌、切割、换目标和返回；不是把玩家手里的武器替换成普通电锯。
- **zmd科技**：白灰机身、黄色绝缘件的双电线塔，连线和索敌电弧。工业元素用像素和克制配色融入世界。
- **帝江号轨道炮**：zmd Lv.3 + pelican Lv.3 + 宝箱合成。视觉阶段为锁定、蓄能、舰影与贯击；合成消耗副武器并释放槽位。
- **拦弹**：所有武器与神器的实际攻击区域可抵消相碰的小怪/精英弹丸，显示短促火花；一般攻击不把首领弹幕或地面危险区一并清除。镜盾已有机制单独保留。
- **祈愿庭院**：营地北侧相连的樱花庭院，y=-800 背景，角色可点击鸟居或步行进入，庭院内可自动返回。樱花、落樱、鸟居和解锁光效为现行视觉；悬浮入口按钮已移除。中央始火巨像默认 Lv.1、持续升级；四小像为伤害、生命、移速、攻速。交互为走近单座、聚焦现场、按住祭器/E 注火 1 秒；松手取消，一次长按只供奉一次。旧五卡片升级面板已撤下。美术和 UI 编辑不要复原成单张不可互动背景。
- **永久祝福**：profile.shrines 经 `expeditionBoons` 进入下一次出发属性，单人/联机各自生效；不在进行中的对局根据新输入重算。旧存档自动补中央雕像。
- **暂停返回**：暂停菜单可手动结算一次并离开。`mayReturn` 仍用于判断自动返回，不要把它改为始终 true；手动按钮有单独处理。

## 资源与运行

- 图片在 `public/art`，源绘制脚本在 `tools`；NPC 生图提示在 `art/npc-portrait-prompts.json`。
- 新增 renderer 使用的图片时更新 `lib/assets.mjs` 的图片清单与计数，保留 decode 后进入游戏、失败重试的流程。当前总量 26 含字体就绪，未来从清单重新核对。
- 修改共享武器 PNG 后检查 renderer 与 CSS 的版本参数，避免图标仍命中旧缓存。不要改图集行数而忘了 `WEAPON_ATLAS_ROWS`/背景取样尺寸。
- Node 版本按 package.json；常用：`npm run dev`、`npx tsc --noEmit`、`npm run build`。
- 默认 dev 为 localhost:5173。先复用已有服务并核对其 cwd，不随意终止用户进程；需隔离时可 `npm run dev -- --port 5174`。
- Python 重绘需 Pillow；此机可用工作区 `.venv/bin/python`，其他环境自行核对。UI 修改不需要重绘。

## 按改动验证

| 改动 | 适合的验证 |
| --- | --- |
| 面板/CSS | 类型检查、构建、真实浏览器检查；桌面/受影响的窄屏/矮窗口 |
| 庭院供奉手势、成长或寻路 | node --test tests/shrine-ritual.test.mjs tests/sanctuary.test.mjs tests/camp.test.mjs |
| 图集或 renderer | node --test tests/assets.test.mjs tests/rendering.test.mjs tests/weapon-vfx.test.mjs |
| 新攻击、合成、拦弹 | node --test tests/meme-arsenal.test.mjs tests/pelican.test.mjs tests/zmd.test.mjs tests/counterfire.test.mjs tests/arsenal.test.mjs |
| 祝福联机数据通路 | 在本地服务上 node tests/sanctuary.integration.mjs |

测试文件及命令存在性先核对。UI 任务不必机械执行全部长时间模拟，涉及共享攻击/快照等广泛改动时再扩展回归。

新增首领/工艺验证：`node --test tests/encounter-expansion.test.mjs tests/rendering.test.mjs`，本地 API 用 `node tests/encounter-expansion.integration.mjs`。共享经验用 `node --test tests/team-experience.test.mjs tests/shared-draft.test.mjs`、`node tests/team-experience.integration.mjs`；大首领图集/镜头用 tests/boss-presentation.test.mjs。手动预览 `/tests/browser/encounter-expansion.html` 复用真实 World、BossHud、SmithPanel，测试数据不写营地存档。

## 交接输出

告知修改文件、实际验证及限制，给出本地地址或截图。保留用户未提交修改、营地存档和本地运行数据。无需把本记录中的历史执行过程或所有规则重新讲给用户。
